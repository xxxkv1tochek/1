import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from collections import Counter
import numpy as np
import json
import os

# Налаштування сторінки
st.set_page_config(
    page_title="mod37 Analyzer",
    page_icon="🔢",
    layout="wide"
)

def validate_input(data):
    """Валідація введених даних"""
    try:
        # Перевіряємо, чи є дані
        if not data.strip():
            return False, "Будь ласка, введіть числа"
        
        # Розбираємо числа
        numbers = [int(n) for n in data.strip().split()]
        
        # Перевіряємо діапазон (0-36)
        invalid_numbers = [n for n in numbers if n < 0 or n > 36]
        if invalid_numbers:
            return False, f"Числа повинні бути в діапазоні 0-36. Неправильні числа: {invalid_numbers}"
        
        # Перевіряємо мінімальну кількість
        if len(numbers) < 4:
            return False, "Потрібно ввести принаймні 4 числа для аналізу"
        
        return True, numbers
    
    except ValueError:
        return False, "Будь ласка, введіть лише цілі числа, розділені пробілами"

def mod37_analysis(numbers):
    """Аналіз модуля 37 для послідовності чисел"""
    # Числа вже в діапазоні 0-36, тому не потрібно mod 37
    mod_numbers = numbers
    
    mods = []
    
    # Аналізуємо кроки 1, 2, 3
    for step in range(1, 4):
        for i in range(len(mod_numbers) - step):
            a = mod_numbers[i]
            b = mod_numbers[i + step]
            mods.append((a + b) % 37)
            mods.append((a - b) % 37)
    
    # Підраховуємо частоти
    count = Counter(mods)
    
    # Створюємо повний список частот для всіх чисел 0-36
    all_frequencies = []
    for i in range(37):
        frequency = count.get(i, 0)
        if frequency > 0:  # Додаємо тільки ті, що мають частоту більше 0
            all_frequencies.append((i, frequency))
    
    # Сортуємо за частотою (найчастіші спочатку)
    all_frequencies.sort(key=lambda x: x[1], reverse=True)
    
    # Топ-13 для прогнозу
    top_13 = all_frequencies[:13]
    
    return all_frequencies, top_13, mod_numbers

def create_frequency_chart(frequency_data):
    """Створення діаграми частот"""
    values = [item[0] for item in frequency_data]
    frequencies = [item[1] for item in frequency_data]
    
    fig = go.Figure(data=[
        go.Bar(
            x=values,
            y=frequencies,
            marker_color='steelblue',
            text=frequencies,
            textposition='auto',
        )
    ])
    
    fig.update_layout(
        title="Розподіл частот залишків (mod 37)",
        xaxis_title="Значення залишку",
        yaxis_title="Частота",
        showlegend=False,
        height=400
    )
    
    return fig

def create_sequence_chart(mod_numbers):
    """Створення діаграми послідовності"""
    fig = go.Figure()
    
    fig.add_trace(go.Scatter(
        x=list(range(len(mod_numbers))),
        y=mod_numbers,
        mode='lines+markers',
        name='Послідовність mod 37',
        line=dict(color='darkblue', width=2),
        marker=dict(size=8)
    ))
    
    fig.update_layout(
        title="Послідовність чисел (mod 37)",
        xaxis_title="Позиція",
        yaxis_title="Значення (mod 37)",
        showlegend=False,
        height=400
    )
    
    return fig

# Функції для роботи з збереженими даними
def load_saved_data():
    """Завантаження збережених даних з файлу"""
    if os.path.exists('saved_data.json'):
        try:
            with open('saved_data.json', 'r', encoding='utf-8') as f:
                return json.load(f)
        except:
            return {}
    return {}

def save_data(data):
    """Збереження даних у файл"""
    with open('saved_data.json', 'w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, indent=2)

def find_next_numbers(sequence, target_number):
    """Знаходить можливі числа після заданого числа в послідовності"""
    next_numbers = []
    for i in range(len(sequence) - 1):
        if sequence[i] == target_number:
            next_numbers.append(sequence[i + 1])
    return list(set(next_numbers))  # Унікальні значення

def analyze_excel_data(df):
    """Аналіз даних з Excel файлу"""
    # Перетворюємо всі стовпці в один список чисел
    all_numbers = []
    for column in df.columns:
        column_data = df[column].dropna().tolist()
        all_numbers.extend([int(x) for x in column_data if str(x).isdigit() and 0 <= int(x) <= 36])
    
    return all_numbers

def main():
    # Заголовок
    st.title("🔢 mod37 Математичний Аналізатор")
    st.markdown("---")
    
    # Завантаження збережених даних
    if 'saved_data' not in st.session_state:
        st.session_state.saved_data = load_saved_data()
    
    # Створюємо вкладки
    tab1, tab2, tab3 = st.tabs(["📝 Ручне введення", "📊 Excel дані", "📋 Таблиця зв'язків"])
    
    with tab1:
        # Опис програми
        with st.expander("ℹ️ Про програму"):
            st.markdown("""
            **mod37 Analyzer** - це інструмент для аналізу числових послідовностей за модулем 37.
            
            **Як це працює:**
            1. Програма приймає числа від 0 до 36
            2. Аналізує різниці та суми для кроків 1, 2, 3
            3. Підраховує частоти залишків
            4. Генерує прогноз на основі найчастіших значень
            
            **Використання:**
            - Введіть числа через пробіл (0-36, мінімум 4)
            - Аналіз відбувається автоматично
            - Переглядайте результати та візуалізації
            """)
        
        # Поле для введення
        st.subheader("📝 Введення даних")
        
        # Приклад використання
        st.markdown("**Приклад:** 5 12 23 31 7 19 25 8 14 33 2 28 16")
        
        # Поле вводу
        input_data = st.text_input(
            "Введіть числа через пробіл (0-36):",
            placeholder="5 12 23 31 7 19 25 8 14 33 2 28 16"
        )
        
        # Обробка ручного введення
        handle_manual_input(input_data)
    
    with tab2:
        # Вкладка для Excel даних
        st.subheader("📊 Робота з Excel файлами")
        
        # Завантаження Excel файлу
        uploaded_file = st.file_uploader("Завантажте Excel файл", type=['xlsx', 'xls'])
        
        if uploaded_file is not None:
            try:
                # Читаємо Excel файл
                df = pd.read_excel(uploaded_file)
                st.success("✅ Файл успішно завантажено!")
                
                # Аналізуємо дані
                excel_numbers = analyze_excel_data(df)
                
                if excel_numbers:
                    # Зберігаємо дані
                    st.session_state.saved_data['excel_data'] = excel_numbers
                    save_data(st.session_state.saved_data)
                    
                    st.info(f"Знайдено {len(excel_numbers)} валідних чисел (0-36)")
                    
                    # Показуємо перші 20 чисел
                    st.write("**Перші 20 чисел:**", excel_numbers[:20])
                    
                    # Пошук наступних чисел
                    st.subheader("🔍 Пошук можливих наступних чисел")
                    
                    search_number = st.number_input(
                        "Введіть число для пошуку (0-36):",
                        min_value=0,
                        max_value=36,
                        value=0
                    )
                    
                    if st.button("Знайти наступні числа"):
                        next_numbers = find_next_numbers(excel_numbers, search_number)
                        
                        if next_numbers:
                            st.success(f"Після числа {search_number} може йти:")
                            
                            # Показуємо результати у квадратах
                            display_prediction_boxes(next_numbers)
                            
                            # Статистика
                            st.info(f"""
                            **Статистика:**
                            - Кількість можливих чисел: {len(next_numbers)}
                            - Числа: {sorted(next_numbers)}
                            - Середнє значення: {np.mean(next_numbers):.2f}
                            """)
                        else:
                            st.warning(f"Після числа {search_number} не знайдено наступних чисел")
                
                else:
                    st.error("У файлі не знайдено валідних чисел (0-36)")
                    
            except Exception as e:
                st.error(f"Помилка при читанні файлу: {str(e)}")
        
        # Показуємо збережені дані
        if 'excel_data' in st.session_state.saved_data:
            st.subheader("💾 Збережені дані")
            
            saved_numbers = st.session_state.saved_data['excel_data']
            st.info(f"Збережено {len(saved_numbers)} чисел")
            
            # Редагування даних
            if st.button("Очистити збережені дані"):
                if 'excel_data' in st.session_state.saved_data:
                    del st.session_state.saved_data['excel_data']
                    save_data(st.session_state.saved_data)
                    st.success("Дані очищено!")
                    st.rerun()
            
            # Показуємо дані у вигляді таблиці
            with st.expander("Переглянути всі збережені дані"):
                df_saved = pd.DataFrame({
                    'Позиція': range(1, len(saved_numbers) + 1),
                    'Число': saved_numbers
                })
                st.dataframe(df_saved, use_container_width=True)
    
    with tab3:
        # Вкладка для ручного створення таблиці зв'язків
        st.subheader("📋 Таблиця зв'язків чисел")
        
        # Ініціалізація таблиці зв'язків
        if 'connections_table' not in st.session_state.saved_data:
            st.session_state.saved_data['connections_table'] = {}
            save_data(st.session_state.saved_data)
        
        # Форма для додавання нового зв'язку
        st.subheader("➕ Додати новий зв'язок")
        
        col1, col2 = st.columns([1, 2])
        
        with col1:
            base_number = st.number_input(
                "Базове число (0-36):",
                min_value=0,
                max_value=36,
                value=0,
                key="base_number"
            )
        
        with col2:
            next_numbers_input = st.text_input(
                "Наступні числа (через пробіл):",
                placeholder="5 12 36",
                key="next_numbers_input"
            )
        
        if st.button("Додати зв'язок"):
            if next_numbers_input:
                try:
                    # Парсимо наступні числа
                    next_numbers = [int(x) for x in next_numbers_input.split()]
                    
                    # Перевіряємо діапазон
                    invalid_numbers = [n for n in next_numbers if n < 0 or n > 36]
                    if invalid_numbers:
                        st.error(f"Неправильні числа (поза діапазоном 0-36): {invalid_numbers}")
                    else:
                        # Додаємо або оновлюємо зв'язок
                        if str(base_number) not in st.session_state.saved_data['connections_table']:
                            st.session_state.saved_data['connections_table'][str(base_number)] = []
                        
                        # Додаємо нові числа до існуючих
                        existing_numbers = st.session_state.saved_data['connections_table'][str(base_number)]
                        for num in next_numbers:
                            if num not in existing_numbers:
                                existing_numbers.append(num)
                        
                        # Зберігаємо дані
                        save_data(st.session_state.saved_data)
                        st.success(f"Зв'язок додано: {base_number} → {next_numbers}")
                        st.rerun()
                
                except ValueError:
                    st.error("Будь ласка, введіть лише цілі числа через пробіл")
            else:
                st.warning("Введіть наступні числа")
        
        # Показуємо існуючі зв'язки
        connections = st.session_state.saved_data['connections_table']
        
        if connections:
            st.subheader("📊 Існуючі зв'язки")
            
            # Створюємо таблицю для відображення
            display_data = []
            for base_num, next_nums in connections.items():
                display_data.append({
                    'Базове число': int(base_num),
                    'Наступні числа': ', '.join(map(str, next_nums)),
                    'Кількість': len(next_nums)
                })
            
            if display_data:
                df_connections = pd.DataFrame(display_data)
                df_connections = df_connections.sort_values('Базове число')
                st.dataframe(df_connections, use_container_width=True)
                
                # Пошук за базовим числом
                st.subheader("🔍 Пошук зв'язків")
                
                search_base = st.number_input(
                    "Введіть базове число для пошуку:",
                    min_value=0,
                    max_value=36,
                    value=0,
                    key="search_base"
                )
                
                # Автоматичний пошук при зміні числа
                if str(search_base) in connections:
                    next_numbers = connections[str(search_base)]
                    st.success(f"Після числа {search_base} можуть йти:")
                    
                    # Показуємо результати у квадратах (зберігаємо порядок введення)
                    display_prediction_boxes(next_numbers)
                    
                    # Статистика
                    st.info(f"""
                    **Статистика:**
                    - Кількість можливих чисел: {len(next_numbers)}
                    - Числа: {next_numbers}
                    - Середнє значення: {np.mean(next_numbers):.2f}
                    """)
                else:
                    if search_base != 0:  # Не показуємо попередження для початкового значення
                        st.warning(f"Для числа {search_base} не знайдено зв'язків")
                
                # Редагування та видалення
                st.subheader("✏️ Редагування зв'язків")
                
                # Вибір базового числа для редагування
                base_numbers = [int(x) for x in connections.keys()]
                if base_numbers:
                    selected_base = st.selectbox(
                        "Виберіть базове число для редагування:",
                        sorted(base_numbers),
                        key="edit_base"
                    )
                    
                    if str(selected_base) in connections:
                        current_numbers = connections[str(selected_base)]
                        st.write(f"Поточні наступні числа: {current_numbers}")
                        
                        # Видалення окремих чисел
                        if current_numbers:
                            numbers_to_remove = st.multiselect(
                                "Виберіть числа для видалення:",
                                current_numbers,
                                key="remove_numbers"
                            )
                            
                            if st.button("Видалити вибрані числа", key="remove_selected"):
                                for num in numbers_to_remove:
                                    if num in st.session_state.saved_data['connections_table'][str(selected_base)]:
                                        st.session_state.saved_data['connections_table'][str(selected_base)].remove(num)
                                
                                # Якщо список порожній, видаляємо весь зв'язок
                                if not st.session_state.saved_data['connections_table'][str(selected_base)]:
                                    del st.session_state.saved_data['connections_table'][str(selected_base)]
                                
                                save_data(st.session_state.saved_data)
                                st.success("Числа видалено!")
                                st.rerun()
                        
                        # Видалення всього зв'язку
                        if st.button(f"Видалити весь зв'язок для {selected_base}", key="remove_connection"):
                            del st.session_state.saved_data['connections_table'][str(selected_base)]
                            save_data(st.session_state.saved_data)
                            st.success(f"Зв'язок для числа {selected_base} видалено!")
                            st.rerun()
                
                # Очищення всіх даних
                st.subheader("🗑️ Очищення даних")
                if st.button("Очистити всі зв'язки", key="clear_all_connections"):
                    st.session_state.saved_data['connections_table'] = {}
                    save_data(st.session_state.saved_data)
                    st.success("Всі зв'язки очищено!")
                    st.rerun()
        
        else:
            st.info("Поки що немає жодних зв'язків. Додайте перший зв'язок вище.")

def display_prediction_boxes(numbers):
    """Відображення чисел у квадратах"""
    # CSS для квадратів
    st.markdown("""
    <style>
    .prediction-box {
        display: inline-block;
        width: 60px;
        height: 60px;
        background-color: #f0f2f6;
        border: 2px solid #4CAF50;
        border-radius: 8px;
        text-align: center;
        line-height: 56px;
        font-size: 20px;
        font-weight: bold;
        margin: 5px;
        color: #333;
    }
    .prediction-container {
        text-align: center;
        margin: 20px 0;
    }
    </style>
    """, unsafe_allow_html=True)
    
    # Створюємо HTML для квадратів
    boxes_html = '<div class="prediction-container">'
    for i, num in enumerate(numbers):
        boxes_html += f'<div class="prediction-box">{num}</div>'
        if (i + 1) % 7 == 0:  # Новий рядок кожні 7 квадратів
            boxes_html += '<br>'
    boxes_html += '</div>'
    
    st.markdown(boxes_html, unsafe_allow_html=True)

def handle_manual_input(input_data):
    """Обробка ручного введення даних"""
    # Автоматичний аналіз при введенні
    if input_data:
        # Валідація
        is_valid, result = validate_input(input_data)
        
        if is_valid:
            numbers = result
            
            # Виконуємо аналіз
            all_frequencies, top_13, mod_numbers = mod37_analysis(numbers)
            
            # Відображаємо результати
            st.success(f"✅ Аналіз завершено! Оброблено {len(numbers)} чисел.")
            
            # Прогноз у квадратах відразу після повідомлення (топ-13)
            prediction = [val for val, _ in top_13]
            display_prediction_boxes(prediction)
            
            # Блок 1: Частоти залишків
            with st.container():
                st.subheader("📊 Частоти залишків (mod 37)")
                
                # Показуємо вкладки: всі частоти та топ-13
                freq_tab1, freq_tab2 = st.tabs(["Всі частоти", "Топ-13"])
                
                with freq_tab1:
                    # Таблиця всіх частот
                    df_all_freq = pd.DataFrame(all_frequencies, columns=['Значення', 'Частота'])
                    st.dataframe(df_all_freq, use_container_width=True)
                    
                    # Діаграма всіх частот
                    all_freq_chart = create_frequency_chart(all_frequencies)
                    st.plotly_chart(all_freq_chart, use_container_width=True)
                
                with freq_tab2:
                    # Таблиця топ-13
                    df_top_freq = pd.DataFrame(top_13, columns=['Значення', 'Частота'])
                    st.dataframe(df_top_freq, use_container_width=True)
                    
                    # Діаграма топ-13
                    top_freq_chart = create_frequency_chart(top_13)
                    st.plotly_chart(top_freq_chart, use_container_width=True)
            
            # Блок 2: Статистика прогнозу
            with st.container():
                st.subheader("📊 Статистика прогнозу")
                
                # Статистика
                st.info(f"""
                **Статистика прогнозу:**
                - Середнє значення: {np.mean(prediction):.2f}
                - Мінімальне значення: {min(prediction)}
                - Максимальне значення: {max(prediction)}
                - Стандартне відхилення: {np.std(prediction):.2f}
                """)
            
            # Блок 3: Візуалізації
            with st.container():
                st.subheader("📈 Візуалізації")
                
                tab1, tab2 = st.tabs(["Послідовність", "Розподіл"])
                
                with tab1:
                    # Діаграма послідовності
                    seq_chart = create_sequence_chart(mod_numbers)
                    st.plotly_chart(seq_chart, use_container_width=True)
                    
                    # Показуємо оригінальну послідовність
                    st.subheader("📋 Оброблені дані")
                    original_df = pd.DataFrame({
                        'Позиція': range(1, len(numbers) + 1),
                        'Число': numbers
                    })
                    st.dataframe(original_df, use_container_width=True)
                
                with tab2:
                    # Гістограма розподілу
                    hist_fig = px.histogram(
                        x=mod_numbers,
                        nbins=37,
                        title="Гістограма розподілу значень",
                        labels={'x': 'Значення', 'y': 'Частота'}
                    )
                    st.plotly_chart(hist_fig, use_container_width=True)
            
            # Блок 4: Детальний аналіз
            with st.container():
                with st.expander("🔬 Детальний аналіз"):
                    st.subheader("Аналіз кроків")
                    
                    # Аналіз по кроках
                    for step in range(1, 4):
                        st.write(f"**Крок {step}:**")
                        step_data = []
                        
                        for i in range(len(mod_numbers) - step):
                            a = mod_numbers[i]
                            b = mod_numbers[i + step]
                            sum_mod = (a + b) % 37
                            diff_mod = (a - b) % 37
                            
                            step_data.append({
                                'Позиція': f"{i+1} → {i+step+1}",
                                'a': a,
                                'b': b,
                                '(a + b) % 37': sum_mod,
                                '(a - b) % 37': diff_mod
                            })
                        
                        step_df = pd.DataFrame(step_data)
                        st.dataframe(step_df, use_container_width=True)
                        st.markdown("---")
        
        else:
            st.error(f"❌ Помилка: {result}")
    
    # Додаткова інформація
    st.markdown("---")
    st.markdown("**💡 Поради:**")
    st.markdown("""
    - Для кращого аналізу використовуйте принаймні 10-15 чисел
    - Числа повинні бути в діапазоні 0-36
    - Аналіз відбувається автоматично при введенні
    - Прогноз базується на найчастіших залишках з аналізу
    """)

if __name__ == "__main__":
    main()
