# Overview

This is a **mod37 Analyzer** application built with Streamlit that analyzes sequences of numbers using modulo 37 mathematical operations. The application provides data validation, statistical analysis, and interactive visualizations using Plotly for number sequences within the range 13-500.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: Streamlit - A Python web framework for rapid data app development
- **Visualization**: Plotly Express and Plotly Graph Objects for interactive charts and graphs
- **Layout**: Wide layout configuration for better data presentation
- **Data Processing**: Pandas for data manipulation and analysis

### Backend Architecture
- **Language**: Python
- **Core Logic**: Mathematical analysis using modulo 37 operations
- **Data Validation**: Custom validation functions for input sanitization
- **Statistical Analysis**: NumPy and collections.Counter for numerical computations

## Key Components

### 1. Input Validation System
- **Purpose**: Ensures data integrity and user input safety
- **Implementation**: `validate_input()` function with comprehensive error handling
- **Validation Rules**:
  - Numbers must be in range 13-500
  - Minimum 4 numbers required for analysis
  - Only integer values accepted
  - Space-separated input format

### 2. Mathematical Analysis Engine
- **Core Function**: `mod37_analysis()` - performs modulo 37 operations on number sequences
- **Analysis Steps**: Processes sequences with step sizes 1, 2, and 3
- **Data Transformation**: Converts input numbers to modulo 37 equivalents

### 3. User Interface
- **Page Configuration**: Custom title, icon, and wide layout
- **Interactive Elements**: Streamlit components for data input and result display
- **Responsive Design**: Optimized for various screen sizes

## Data Flow

1. **Input Stage**: User enters space-separated numbers via Streamlit interface
2. **Validation**: Input is validated for format, range, and minimum count requirements
3. **Processing**: Valid numbers are processed through mod37 analysis algorithm
4. **Analysis**: Mathematical operations are performed on the sequence
5. **Visualization**: Results are displayed using Plotly charts and graphs
6. **Output**: Statistical summaries and visual representations are presented

## External Dependencies

### Core Libraries
- **streamlit**: Web application framework
- **pandas**: Data manipulation and analysis
- **plotly.express**: High-level plotting interface
- **plotly.graph_objects**: Low-level plotting components
- **numpy**: Numerical computing
- **collections.Counter**: Counting and frequency analysis

### System Requirements
- Python 3.7+ compatibility
- Web browser for Streamlit interface
- No database dependencies (in-memory processing)

## Deployment Strategy

### Local Development
- **Run Command**: `streamlit run app.py`
- **Environment**: Python virtual environment recommended
- **Dependencies**: Install via `pip install streamlit pandas plotly numpy`

### Production Considerations
- **Hosting**: Compatible with Streamlit Cloud, Heroku, or similar platforms
- **Scaling**: Single-threaded application suitable for moderate traffic
- **Performance**: In-memory processing limits dataset size
- **Security**: Input validation prevents basic injection attacks

### Architecture Decisions

1. **Streamlit Choice**: 
   - **Problem**: Need for rapid prototyping of data analysis tool
   - **Solution**: Streamlit provides quick web interface development
   - **Pros**: Fast development, built-in widgets, easy deployment
   - **Cons**: Limited customization, single-threaded execution

2. **Plotly for Visualization**:
   - **Problem**: Interactive charts needed for data exploration
   - **Solution**: Plotly provides rich interactive visualizations
   - **Pros**: Interactive features, professional appearance, web-ready
   - **Cons**: Larger bundle size than static plotting libraries

3. **In-Memory Processing**:
   - **Problem**: Simple analysis tool for moderate datasets
   - **Solution**: Process data in memory without persistence
   - **Pros**: Simplicity, fast processing, no database overhead
   - **Cons**: No data persistence, memory limitations for large datasets

4. **Input Validation Strategy**:
   - **Problem**: Ensure mathematical operations work correctly
   - **Solution**: Comprehensive validation with clear error messages
   - **Pros**: Prevents crashes, good user experience
   - **Cons**: Additional complexity in input handling

## Recent Changes: Latest modifications with dates

### July 17, 2025
- **Added Excel Integration**: New tab for uploading Excel files with data persistence
- **Data Persistence**: Implemented JSON-based storage for Excel data across sessions
- **Search Functionality**: Added ability to search for possible next numbers based on historical data
- **Improved UI**: Moved prediction boxes directly under completion message
- **Enhanced Data Handling**: Numbers now validated as 0-36 range (not mod 37 conversion)
- **Two-Tab System**: Separated manual input and Excel data into distinct tabs